package com.att.facedbcreator.main;

import java.io.IOException;

import com.att.facedetection.core.FacedetectionProcess;
import com.att.facedetection.core.FacedetectionUtility;
import com.att.facedetection.exception.FacedetectionException;
import com.att.facedetection.exception.PropertyFileException;
import com.att.facedetection.prop.FacedetectionPropertyReader;
import com.att.facelearning.core.FaceLearning;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class FacedbCreatorMain {

	static private FacedetectionProcess fdProcess = null;
	static private FacedetectionPropertyReader fdProperties = null;
	static private FileHandler logFile;

	private final static Logger LOGGER = Logger
			.getLogger(FacedbCreatorMain.class.getName());

	public static void main(String[] args) {
		LOGGER.setLevel(Level.INFO);
		fdProcess = new FacedetectionProcess();
		try {
			logFile = new FileHandler("facedetection.log");
			logFile.setFormatter(new SimpleFormatter());
			LOGGER.addHandler(logFile);
			fdProperties = new FacedetectionPropertyReader(
					"fdconfig.properties");
			FacedetectionUtility.checkDirectoryandCreate(fdProperties
					.readProperty("destinationImageDirectory"));
			FacedetectionUtility.checkDirectoryandCreate(fdProperties
					.readProperty("facedbDataDirectory"));
			fdProcess.detectFaces(
					fdProperties.readProperty("sourceImageDirectory"),
					fdProperties.readProperty("destinationImageDirectory"),
					fdProperties.readProperty("cascadeAlgorithmXMLPath"));

			FaceLearning.learn(fdProperties
					.readProperty("destinationImageDirectory"),fdProperties
					.readProperty("facedbDataDirectory"));

		} catch (FacedetectionException e) {
			LOGGER.log(
					Level.ALL,
					"Exception in detection of faces using OpenCV  API : "
							+ e.getStackTrace());
			e.printStackTrace();
		} catch (PropertyFileException e) {
			LOGGER.log(Level.ALL,
					"Exception in property file module : " + e.getStackTrace());
			e.printStackTrace();
		} catch (IOException e) {
			LOGGER.log(
					Level.ALL,
					"IO Exception in property file module : "
							+ e.getStackTrace());
		}
	}
}