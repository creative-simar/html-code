package com.att.facelearning.core;

import static com.googlecode.javacv.cpp.opencv_core.CV_32FC1;
import static com.googlecode.javacv.cpp.opencv_core.CV_32SC1;

import com.googlecode.javacpp.FloatPointer;
import com.googlecode.javacv.cpp.opencv_core.CvMat;

public class FaceDetectionHelper {
	
	
	 /** Returns a string representation of the given float array.
	   *
	   * @param floatArray the given float array
	   * @return a string representation of the given float array
	   */
	  public static String floatArrayToString(final float[] floatArray) {
	    final StringBuilder stringBuilder = new StringBuilder();
	    boolean isFirst = true;
	    stringBuilder.append('[');
	    for (int i = 0; i < floatArray.length; i++) {
	      if (isFirst) {
	        isFirst = false;
	      } else {
	        stringBuilder.append(", ");
	      }
	      stringBuilder.append(floatArray[i]);
	    }
	    stringBuilder.append(']');

	    return stringBuilder.toString();
	  }

	  /** Returns a string representation of the given float pointer.
	   *
	   * @param floatPointer the given float pointer
	   * @return a string representation of the given float pointer
	   */
	  public static String floatPointerToString(final FloatPointer floatPointer) {
	    final StringBuilder stringBuilder = new StringBuilder();
	    boolean isFirst = true;
	    stringBuilder.append('[');
	    for (int i = 0; i < floatPointer.capacity(); i++) {
	      if (isFirst) {
	        isFirst = false;
	      } else {
	        stringBuilder.append(", ");
	      }
	      stringBuilder.append(floatPointer.get(i));
	    }
	    stringBuilder.append(']');

	    return stringBuilder.toString();
	  }

	  /** Returns a string representation of the given one-channel CvMat object.
	   *
	   * @param cvMat the given CvMat object
	   * @return a string representation of the given CvMat object
	   */
	  public static String oneChannelCvMatToString(final CvMat cvMat) {
	    //Preconditions
	    if (cvMat.channels() != 1) {
	      throw new RuntimeException("illegal argument - CvMat must have one channel");
	    }

	    final int type = cvMat.maskedType();
	    StringBuilder s = new StringBuilder("[ ");
	    for (int i = 0; i < cvMat.rows(); i++) {
	      for (int j = 0; j < cvMat.cols(); j++) {
	        if (type == CV_32FC1 || type == CV_32SC1) {
	          s.append(cvMat.get(i, j));
	        } else {
	          throw new RuntimeException("illegal argument - CvMat must have one channel and type of float or signed integer");
	        }
	        if (j < cvMat.cols() - 1) {
	          s.append(", ");
	        }
	      }
	      if (i < cvMat.rows() - 1) {
	        s.append("\n  ");
	      }
	    }
	    s.append(" ]");
	    return s.toString();
	  }


}
