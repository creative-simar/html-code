package com.att.facelearning.core;

import static com.googlecode.javacv.cpp.opencv_core.CV_32FC1;
import static com.googlecode.javacv.cpp.opencv_core.cvCreateMat;
import static com.googlecode.javacv.cpp.opencv_legacy.cvEigenDecomposite;

import java.io.IOException;
import java.util.logging.Logger;

import com.att.facedb.utility.FaceLearningUtility;
import com.att.facedbcreator.main.FacedbCreatorMain;
import com.att.facelearning.db.FaceDBCreation;
import com.googlecode.javacpp.FloatPointer;
import com.googlecode.javacpp.PointerPointer;
import com.googlecode.javacv.cpp.opencv_core.CvMat;
import com.googlecode.javacv.cpp.opencv_core.IplImage;

public class FaceLearning {
	
	
	/** the logger */
	  private static final Logger LOGGER = Logger.getLogger(FacedbCreatorMain.class.getName());
	  
	  /** the training face image array */
	  //static IplImage[] trainingFaceImgArr;
	  /** the test face image array */
	  static IplImage[] testFaceImgArr;
	  /** the average image */
	  static IplImage pAvgTrainImg;
	  /** the projected training faces */
	  static CvMat projectedTrainFaceMat;
	  /** the number of eigenvalues */
	 // static int nEigens = 0;
	  /** the number of training faces */	  
	 /** eigenvectors */
	  //static IplImage[] eigenVectArr;
	  
	  
      
	 /** Trains from the data in the given training text index file, and store the trained data into the file 'data/facedata.xml'.
	   *
	   * @param trainingFileName the given training text index file
	 * @throws IOException 
	   */
	  public static void learn(final String trainingDirectoryName, String outfacedbDirectoryName) throws IOException {
	    int i;
	    int nTrainFaces = 0;
	    int nEigens = 0;
	    IplImage[] eigenVectArr;
	    IplImage[] trainingFaceImgArr;
	    // load training data
	    LOGGER.info("===========================================");
	    LOGGER.info("Loading the training images in " + trainingDirectoryName);
	    trainingFaceImgArr = FaceLearningUtility.loadFaceImgArray(trainingDirectoryName);
	    nTrainFaces = trainingFaceImgArr.length;
	    LOGGER.info("Got " + nTrainFaces + " training images");
	    if (nTrainFaces < 3) {
	      LOGGER.severe("Need 3 or more training faces\n"
	              + "Input file contains only " + nTrainFaces);
	      return;
	    }

	    // do Principal Component Analysis on the training faces
	     eigenVectArr =  FaceLearningUtility.doPCA(nTrainFaces,trainingFaceImgArr);
	     nEigens = eigenVectArr.length; 
	    LOGGER.info("projecting the training images onto the PCA subspace");
	    // project the training images onto the PCA subspace
	    projectedTrainFaceMat = cvCreateMat(
	            nTrainFaces, // rows
	            nEigens, // cols
	            CV_32FC1); // type, 32-bit float, 1 channel

	    // initialize the training face matrix - for ease of debugging
	    for (int i1 = 0; i1 < nTrainFaces; i1++) {
	      for (int j1 = 0; j1 < nEigens; j1++) {
	        projectedTrainFaceMat.put(i1, j1, 0.0);
	      }
	    }

	    LOGGER.info("created projectedTrainFaceMat with " + nTrainFaces + " (nTrainFaces) rows and " + nEigens + " (nEigens) columns");
	    if (nTrainFaces < 5) {
	      LOGGER.info("projectedTrainFaceMat contents:\n" + FaceDetectionHelper.oneChannelCvMatToString(projectedTrainFaceMat));
	    }

	    final FloatPointer floatPointer = new FloatPointer(nEigens);
	    
	    pAvgTrainImg= FaceLearningUtility.pAvgTrainImg;
	    for (i = 0; i < nTrainFaces; i++) {
	      cvEigenDecomposite(
	              trainingFaceImgArr[i], // obj
	              nEigens, // nEigObjs
	              new PointerPointer(eigenVectArr), // eigInput (Pointer)
	              0, // ioFlags
	              null, // userData (Pointer)
	              pAvgTrainImg, // avg
	              floatPointer); // coeffs (FloatPointer)

	      if (nTrainFaces < 5) {
	        LOGGER.info("floatPointer: " + FaceDetectionHelper.floatPointerToString(floatPointer));
	      }
	      for (int j1 = 0; j1 < nEigens; j1++) {
	        projectedTrainFaceMat.put(i, j1, floatPointer.get(j1));
	      }
	    }
	    if (nTrainFaces < 5) {
	      LOGGER.info("projectedTrainFaceMat after cvEigenDecomposite:\n" + projectedTrainFaceMat);
	    }

	    // store the recognition data as an xml file
	  FaceDBCreation.storeTrainingData(nEigens,nTrainFaces,pAvgTrainImg,projectedTrainFaceMat,eigenVectArr,outfacedbDirectoryName);

	   
	  }


}
