package com.att.facelearning.db;

import static com.googlecode.javacv.cpp.opencv_core.CV_STORAGE_WRITE;
import static com.googlecode.javacv.cpp.opencv_core.IPL_DEPTH_8U;
import static com.googlecode.javacv.cpp.opencv_core.cvConvertScale;
import static com.googlecode.javacv.cpp.opencv_core.cvCopy;
import static com.googlecode.javacv.cpp.opencv_core.cvCreateImage;
import static com.googlecode.javacv.cpp.opencv_core.cvMinMaxLoc;
import static com.googlecode.javacv.cpp.opencv_core.cvOpenFileStorage;
import static com.googlecode.javacv.cpp.opencv_core.cvRect;
import static com.googlecode.javacv.cpp.opencv_core.cvReleaseFileStorage;
import static com.googlecode.javacv.cpp.opencv_core.cvReleaseImage;
import static com.googlecode.javacv.cpp.opencv_core.cvResetImageROI;
import static com.googlecode.javacv.cpp.opencv_core.cvSetImageROI;
import static com.googlecode.javacv.cpp.opencv_core.cvSize;
import static com.googlecode.javacv.cpp.opencv_core.cvWrite;
import static com.googlecode.javacv.cpp.opencv_core.cvWriteInt;
import static com.googlecode.javacv.cpp.opencv_core.cvWriteString;
import static com.googlecode.javacv.cpp.opencv_highgui.cvSaveImage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.att.facedb.utility.FaceLearningUtility;
import com.att.facedbcreator.main.FacedbCreatorMain;
import com.googlecode.javacv.cpp.opencv_core.CvFileStorage;
import com.googlecode.javacv.cpp.opencv_core.CvMat;
import com.googlecode.javacv.cpp.opencv_core.CvPoint;
import com.googlecode.javacv.cpp.opencv_core.CvRect;
import com.googlecode.javacv.cpp.opencv_core.CvSize;
import com.googlecode.javacv.cpp.opencv_core.IplImage;

public class FaceDBCreation {

	/** the logger */
	private static final Logger LOGGER = Logger
			.getLogger(FacedbCreatorMain.class.getName());

	/** eigenvalues */
	static CvMat eigenValMat;
	/** the person names */
	static List<String> personNames = new ArrayList<String>();
	/** the number of persons */
	static int nPersons;
	/** the number of eigenvalues */
	// static int nEigens = 0;
	/** the number of training faces */
	// private static int nTrainFaces = 0;
	/** the projected training faces */
	// static CvMat projectedTrainFaceMat;
	// /** the average image */
	// static IplImage pAvgTrainImg;
	/** eigenvectors */
	// static IplImage[] eigenVectArr;
	/** the person number array */
	static CvMat personNumTruthMat;

	/**
	 * Stores the training data to the file 'data/facedata.xml'.
	 * 
	 * @throws IOException
	 */
	public static void storeTrainingData(int nEigens, int nTrainFaces,
			IplImage pAvgTrainImg, CvMat projectedTrainFaceMat,
			IplImage[] eigenVectArr, String outfacedbDirectoryName)
			throws IOException {
		CvFileStorage fileStorage;
		int i;

		nPersons = FaceLearningUtility.nPersons;
		personNumTruthMat = FaceLearningUtility.personNumTruthMat;
		eigenValMat = FaceLearningUtility.eigenValMat;
		personNames = FaceLearningUtility.personNames;
		
		System.out.println(nPersons);

		LOGGER.info("writing facedata.xml to " + outfacedbDirectoryName);

		// create a file-storage interface
		fileStorage = cvOpenFileStorage(outfacedbDirectoryName
				+ "\\facedata.xml", // filename
				null, // memstorage
				CV_STORAGE_WRITE, // flags
				null); // encoding

		// Store the person names. Added by Shervin.
		cvWriteInt(fileStorage, // fs
				"nPersons", // name
				nPersons); // value

		for (i = 0; i < nPersons; i++) {
			String varname = "personName_" + (i + 1);
			cvWriteString(fileStorage, // fs
					varname, // name
					personNames.get(i), // string
					0); // quote
		}

		// store all the data
		cvWriteInt(fileStorage, // fs
				"nEigens", // name
				nEigens); // value

		cvWriteInt(fileStorage, // fs
				"nTrainFaces", // name
				nTrainFaces); // value

		cvWrite(fileStorage, // fs
				"trainPersonNumMat", // name
				personNumTruthMat); // value

		cvWrite(fileStorage, // fs
				"eigenValMat", // name
				eigenValMat); // value

		cvWrite(fileStorage, // fs
				"projectedTrainFaceMat", // name
				projectedTrainFaceMat);

		cvWrite(fileStorage, // fs
				"avgTrainImg", // name
				pAvgTrainImg); // value

		for (i = 0; i < nEigens; i++) {
			String varname = "eigenVect_" + i;
			cvWrite(fileStorage, // fs
					varname, // name
					eigenVectArr[i]); // value
		}

		// release the file-storage interface
		cvReleaseFileStorage(fileStorage);

		// System.out.println(personNames);
		storeNamesintoFile(personNames, outfacedbDirectoryName);
		// Save all the eigenvectors as images, so that they can be checked.
		storeEigenfaceImages(nEigens, pAvgTrainImg, eigenVectArr,
				outfacedbDirectoryName);
	}

	private static void storeNamesintoFile(List<String> personContent,
			String outfacedbDirectoryName) throws IOException {

		File file = new File(outfacedbDirectoryName + "\\PersonNames.txt");

		// if file doesnt exists, then create it
		if (!file.exists()) {
			file.createNewFile();
		}

		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(personContent.toString());
		bw.close();

	}

	/**
	 * Opens the training data from the file 'data/facedata.xml'.
	 * 
	 * @param pTrainPersonNumMat
	 * @return the person numbers during training, or null if not successful
	 */
	// public static CvMat loadTrainingData() {
	// LOGGER.info("loading training data");
	// CvMat pTrainPersonNumMat = null; // the person numbers during training
	// CvFileStorage fileStorage;
	// int i;
	//
	// // create a file-storage interface
	// fileStorage = cvOpenFileStorage(
	// "data/facedata.xml", // filename
	// null, // memstorage
	// CV_STORAGE_READ, // flags
	// null); // encoding
	// if (fileStorage == null) {
	// LOGGER.severe("Can't open training database file 'data/facedata.xml'.");
	// return null;
	// }
	//
	// // Load the person names.
	// personNames.clear(); // Make sure it starts as empty.
	// nPersons = cvReadIntByName(
	// fileStorage, // fs
	// null, // map
	// "nPersons", // name
	// 0); // default_value
	// if (nPersons == 0) {
	// LOGGER.severe("No people found in the training database 'data/facedata.xml'.");
	// return null;
	// } else {
	// LOGGER.info(nPersons + " persons read from the training database");
	// }
	//
	// // Load each person's name.
	// for (i = 0; i < nPersons; i++) {
	// String sPersonName;
	// String varname = "personName_" + (i + 1);
	// sPersonName = cvReadStringByName(
	// fileStorage, // fs
	// null, // map
	// varname,
	// "");
	// personNames.add(sPersonName);
	// }
	// LOGGER.info("person names: " + personNames);
	//
	// // Load the data
	// nEigens = cvReadIntByName(
	// fileStorage, // fs
	// null, // map
	// "nEigens",
	// 0); // default_value
	// nTrainFaces = cvReadIntByName(
	// fileStorage,
	// null, // map
	// "nTrainFaces",
	// 0); // default_value
	// Pointer pointer = cvReadByName(
	// fileStorage, // fs
	// null, // map
	// "trainPersonNumMat"); // name
	// pTrainPersonNumMat = new CvMat(pointer);
	//
	// pointer = cvReadByName(
	// fileStorage, // fs
	// null, // map
	// "eigenValMat"); // name
	// eigenValMat = new CvMat(pointer);
	//
	// pointer = cvReadByName(
	// fileStorage, // fs
	// null, // map
	// "projectedTrainFaceMat"); // name
	// projectedTrainFaceMat = new CvMat(pointer);
	//
	// pointer = cvReadByName(
	// fileStorage,
	// null, // map
	// "avgTrainImg");
	// pAvgTrainImg = new IplImage(pointer);
	//
	// eigenVectArr = new IplImage[nTrainFaces];
	// for (i = 0; i < nEigens; i++) {
	// String varname = "eigenVect_" + i;
	// pointer = cvReadByName(
	// fileStorage,
	// null, // map
	// varname);
	// eigenVectArr[i] = new IplImage(pointer);
	// }
	//
	// // release the file-storage interface
	// cvReleaseFileStorage(fileStorage);
	//
	// LOGGER.info("Training data loaded (" + nTrainFaces +
	// " training images of " + nPersons + " people)");
	// final StringBuilder stringBuilder = new StringBuilder();
	// stringBuilder.append("People: ");
	// if (nPersons > 0) {
	// stringBuilder.append("<").append(personNames.get(0)).append(">");
	// }
	// for (i = 1; i < nPersons; i++) {
	// stringBuilder.append(", <").append(personNames.get(i)).append(">");
	// }
	// LOGGER.info(stringBuilder.toString());
	//
	// return pTrainPersonNumMat;
	// }
	//
	/** Saves all the eigenvectors as images, so that they can be checked. */
	private static void storeEigenfaceImages(int nEigens,
			IplImage pAvgTrainImg, IplImage[] eigenVectArr,
			String outfacedbDirectoryName) {
		// Store the average image to a file
		LOGGER.info("Saving the image of the average face as '"
				+ outfacedbDirectoryName + "\\out_averageImage.bmp'");
		cvSaveImage(outfacedbDirectoryName + "\\out_averageImage.bmp",
				pAvgTrainImg);

		// Create a large image made of many eigenface images.
		// Must also convert each eigenface image to a normal 8-bit UCHAR image
		// instead of a 32-bit float image.
		LOGGER.info("Saving the " + nEigens + " eigenvector images as '"
				+ outfacedbDirectoryName + "\\out_eigenfaces.bmp'");

		if (nEigens > 0) {
			// Put all the eigenfaces next to each other.
			int COLUMNS = 8; // Put upto 8 images on a row.
			int nCols = Math.min(nEigens, COLUMNS);
			int nRows = 1 + (nEigens / COLUMNS); // Put the rest on new rows.
			int w = eigenVectArr[0].width();
			int h = eigenVectArr[0].height();
			CvSize size = cvSize(nCols * w, nRows * h);
			final IplImage bigImg = cvCreateImage(size, IPL_DEPTH_8U, // depth,
																		// 8-bit
																		// Greyscale
																		// UCHAR
																		// image
					1); // channels
			for (int i = 0; i < nEigens; i++) {
				// Get the eigenface image.
				IplImage byteImg = convertFloatImageToUcharImage(eigenVectArr[i]);
				// Paste it into the correct position.
				int x = w * (i % COLUMNS);
				int y = h * (i / COLUMNS);
				CvRect ROI = cvRect(x, y, w, h);
				cvSetImageROI(bigImg, // image
						ROI); // rect
				cvCopy(byteImg, // src
						bigImg, // dst
						null); // mask
				cvResetImageROI(bigImg);
				cvReleaseImage(byteImg);
			}
			cvSaveImage(outfacedbDirectoryName + "\\out_eigenfaces.bmp", // filename
					bigImg); // image
			cvReleaseImage(bigImg);
		}
	}

	/**
	 * Converts the given float image to an unsigned character image.
	 * 
	 * @param srcImg
	 *            the given float image
	 * @return the unsigned character image
	 */
	private static IplImage convertFloatImageToUcharImage(IplImage srcImg) {
		IplImage dstImg;
		if ((srcImg != null) && (srcImg.width() > 0 && srcImg.height() > 0)) {
			// Spread the 32bit floating point pixels to fit within 8bit pixel
			// range.
			CvPoint minloc = new CvPoint();
			CvPoint maxloc = new CvPoint();
			double[] minVal = new double[1];
			double[] maxVal = new double[1];
			cvMinMaxLoc(srcImg, minVal, maxVal, minloc, maxloc, null);
			// Deal with NaN and extreme values, since the DFT seems to give
			// some NaN results.
			if (minVal[0] < -1e30) {
				minVal[0] = -1e30;
			}
			if (maxVal[0] > 1e30) {
				maxVal[0] = 1e30;
			}
			if (maxVal[0] - minVal[0] == 0.0f) {
				maxVal[0] = minVal[0] + 0.001; // remove potential divide by
												// zero errors.
			} // Convert the format
			dstImg = cvCreateImage(cvSize(srcImg.width(), srcImg.height()), 8,
					1);
			cvConvertScale(srcImg, dstImg, 255.0 / (maxVal[0] - minVal[0]),
					-minVal[0] * 255.0 / (maxVal[0] - minVal[0]));
			return dstImg;
		}
		return null;
	}

}
