package com.att.facedetection.core;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

import org.opencv.core.Rect;

public class FacedetectionUtility {

	public static boolean checkDirectoryandCreate(String sDirectoryName) throws FileNotFoundException {
		File theDir = new File(sDirectoryName);
		if (!theDir.exists()) {
			return theDir.mkdirs();
		} else
		
			//deleteRecursive(theDir);
			//theDir.mkdirs();
		
			return true;
	}
	
	

	public static int getMaxValueIndex(Rect[] array){  
	      int maxValue = array[0].height;  
	      for(int i=1;i < array.length;i++){  
	      if(array[i].height > maxValue){  
	    	  maxValue = i;  
	         }  
	     }  
	             return maxValue;  
	}  

//	
//	public static boolean deleteRecursive(File path) throws FileNotFoundException{
//        if (!path.exists()) throw new FileNotFoundException(path.getAbsolutePath());
//        boolean ret = true;
//        if (path.isDirectory()){
//            for (File f : path.listFiles()){
//                ret = ret && FacedetectionUtility.deleteRecursive(f);
//            }
//        }
//        return ret && path.delete();
//    }
}
