package com.att.facedetection.core;

import java.io.File;
import java.util.logging.Logger;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;

import com.att.facedbcreator.main.FacedbCreatorMain;
import com.att.facedetection.exception.FacedetectionException;
import com.att.facedetection.iface.FacedetectionInterface;

public class FacedetectionProcess implements FacedetectionInterface {

	private final static Logger LOGGER = Logger
			.getLogger(FacedbCreatorMain.class.getName());

	@Override
	public void detectFaces(String imageSourceDirectoryName,
			String destinationDirectoryName, String cascadeAlgorithmXMLPath)
			throws FacedetectionException {
		Mat image = null;
		Mat grey_image = null;
		MatOfRect faceDetections = null;
		Rect[] rect = null;
		Mat cropImageRegion = null;
		String filename = "";
		int index = 0;
		
		LOGGER.info("Starting face detection.");
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		LOGGER.info("Open CV library loaded sucessfully.");
		
		CascadeClassifier faceDetector = new CascadeClassifier();
		faceDetector.load(cascadeAlgorithmXMLPath);
		
		File path = new File(imageSourceDirectoryName);
		
		File [] files = path.listFiles();
	    for (int i = 0; i < files.length; i++){
	        if (files[i].isFile()){ 
	        	image = null;faceDetections = null;rect=null;cropImageRegion = null;grey_image=null;
	        	image = Highgui.imread(files[i].getAbsolutePath());
	        	faceDetections = new MatOfRect();
	        	grey_image = new Mat();
	        	Imgproc.cvtColor(image, grey_image, Imgproc.COLOR_BGRA2GRAY);
	            Imgproc.equalizeHist(grey_image, grey_image);
	            
	        	LOGGER.info("\nRunning FaceDetector");	        	
	        	faceDetector.detectMultiScale(grey_image, faceDetections);
	    		LOGGER.info(String.format("Detected %s faces",
	    				faceDetections.toArray().length));
	    		rect = faceDetections.toArray();		
	    		// As we are considering only 1 face which is at index 0
	    		
	    		if(rect.length==0) continue;
	    		if(rect.length>1)
	    		{
	    			index = FacedetectionUtility.getMaxValueIndex(rect);
	    		}
	    		
	    		cropImageRegion = new Mat(image, new Rect(rect[0].x, rect[0].y,
	    				rect[0].width, rect[0].height));
	    		
	    		filename = destinationDirectoryName + File.separator + files[i].getName();
	    		
	    		Mat resizeimage = new Mat();
	    		Size sz = new Size(100,100);
	    		Imgproc.resize( cropImageRegion, resizeimage, sz );
	    		
	    		LOGGER.info(String.format("Writing %s", filename));
	    		Highgui.imwrite(filename, resizeimage);

	    		
	        }
	    }
		
	    
		
	}

}
