/**
 * 
 */
package com.att.facedetection.prop;

import com.att.facedetection.exception.PropertyFileException;

/**
 * @author SC00351054
 *
 */
public interface FacedetectionPRInterface {
	
	public String readProperty(String sTag) throws PropertyFileException;

}
