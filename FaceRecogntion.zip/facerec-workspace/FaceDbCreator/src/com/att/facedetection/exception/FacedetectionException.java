package com.att.facedetection.exception;

public class FacedetectionException extends Exception {
	private String message = null;

	public FacedetectionException() {
		super();
	}

	public FacedetectionException(String message) {
		super(message);
		this.message = message;
	}

	public FacedetectionException(Throwable cause) {
		super(cause);
	}

	public FacedetectionException(String message, Throwable cause) {
		super(message, cause);
	}

	@Override
	public String toString() {
		return message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
