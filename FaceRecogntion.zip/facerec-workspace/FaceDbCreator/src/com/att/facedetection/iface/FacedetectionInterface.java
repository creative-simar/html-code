/**
 * 
 */
package com.att.facedetection.iface;

import com.att.facedetection.exception.FacedetectionException;
import com.att.facedetection.exception.PropertyFileException;

/**
 * @author SC00351054
 *
 */
public interface FacedetectionInterface {
	
	public void detectFaces(String imageSourceDirectoryName, String destinationDirectoryName, String cascadeAlgorithmXMLPath) throws FacedetectionException;

}
