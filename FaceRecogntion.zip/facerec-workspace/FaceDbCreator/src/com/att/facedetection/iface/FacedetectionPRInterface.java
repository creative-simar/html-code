/**
 * 
 */
package com.att.facedetection.iface;

/**
 * @author SC00351054
 *
 */
public interface FacedetectionPRInterface {

}
