package com.att.facedb.utility;

import static com.googlecode.javacv.cpp.opencv_core.CV_32FC1;
import static com.googlecode.javacv.cpp.opencv_core.CV_32SC1;
import static com.googlecode.javacv.cpp.opencv_core.CV_L1;
import static com.googlecode.javacv.cpp.opencv_core.CV_TERMCRIT_ITER;
import static com.googlecode.javacv.cpp.opencv_core.IPL_DEPTH_32F;
import static com.googlecode.javacv.cpp.opencv_core.cvCreateImage;
import static com.googlecode.javacv.cpp.opencv_core.cvCreateMat;
import static com.googlecode.javacv.cpp.opencv_core.cvNormalize;
import static com.googlecode.javacv.cpp.opencv_core.cvTermCriteria;
import static com.googlecode.javacv.cpp.opencv_highgui.CV_LOAD_IMAGE_GRAYSCALE;
import static com.googlecode.javacv.cpp.opencv_highgui.cvLoadImage;
import static com.googlecode.javacv.cpp.opencv_legacy.CV_EIGOBJ_NO_CALLBACK;
import static com.googlecode.javacv.cpp.opencv_legacy.cvCalcEigenObjects;

import java.io.BufferedReader;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.att.facedbcreator.main.FacedbCreatorMain;
import com.googlecode.javacpp.PointerPointer;
import com.googlecode.javacv.cpp.opencv_core.CvMat;
import com.googlecode.javacv.cpp.opencv_core.CvSize;
import com.googlecode.javacv.cpp.opencv_core.CvTermCriteria;
import com.googlecode.javacv.cpp.opencv_core.IplImage;

public class FaceLearningUtility {
	
	/** the logger */
	  private static final Logger LOGGER = Logger.getLogger(FacedbCreatorMain.class.getName());
	
	  /** the number of training faces */
	  //private static int nTrainFaces = 0;
	  float[] projectedTestFace;
	  /** the training face image array */
	  //static IplImage[] trainingFaceImgArr;
	  /** the person number array */
	  static public CvMat personNumTruthMat;	  
	  /** the person names */
	  public static List<String> personNames = new ArrayList<String>();
	  /** the number of eigenvalues */
	  //static int nEigens = 0;
	  /** eigenvectors */
	  //static IplImage[] eigenVectArr;
	  /** eigenvalues */
	  static public CvMat eigenValMat;
	  /** the number of persons */
	  static public int nPersons;
	  /** the average image */
	  static public IplImage pAvgTrainImg;
	  /** the projected training faces */
	  CvMat projectedTrainFaceMat;

	  
	  /** Reads the names & image filenames of people from a text file, and loads all those images listed.
	   *
	   * @param filename the training file name
	   * @return the face image array
	   */  
	  public static IplImage[] loadFaceImgArray(final String directoryname) {
	    IplImage[] faceImgArr;
	    BufferedReader imgListFile;
	    String imgFilename;
	    List<String> fileNames;
	    int iFace = 0;
	    int nFaces = 0;
	    int i;
	    try {
	      // open the input file
	     // imgListFile = new BufferedReader(new FileReader(filename));
	    	fileNames = listFiles(directoryname);
	    	nFaces = fileNames.size();
	    	// count the number of faces
//	      while (true) {
//	        final String line = imgListFile.readLine();
//	        if (line == null || line.isEmpty()) {
//	          break;
//	        }
//	        nFaces++;
//	      }
	      LOGGER.info("nFaces: " + nFaces);
	     // imgListFile = new BufferedReader(new FileReader(filename));

	      // allocate the face-image array and person number matrix
	      faceImgArr = new IplImage[nFaces];
	      personNumTruthMat = cvCreateMat(
	              1, // rows
	              nFaces, // cols
	              CV_32SC1); // type, 32-bit unsigned, one channel

	      // initialize the person number matrix - for ease of debugging
	      for (int j1 = 0; j1 < nFaces; j1++) {
	        personNumTruthMat.put(0, j1, 0);
	      }

	      personNames.clear();        // Make sure it starts as empty.
	 //     nPersons = 0;

	      // store the face images in an array
	      for (iFace = 0; iFace < nFaces; iFace++) {
	        String personName;
	        String sPersonName;
	        int personNumber;

	        // read person number (beginning with 1), their name and the image filename.
	   //     final String line = imgListFile.readLine();
	    //    if (line.isEmpty()) {
	    //      break;
	    //    }
	     //   final String[] tokens = line.split(" ");
	        personNumber = iFace;
	        personName = fileNames.get(iFace);
	        imgFilename = directoryname + "\\" + fileNames.get(iFace);
	        sPersonName = personName;
	        LOGGER.info("Got " + iFace + " " + personNumber + " " + personName + " " + imgFilename);

	        // Check if a new person is being loaded.
	      //  if (personNumber > nPersons) {
	          // Allocate memory for the extra person (or possibly multiple), using this new person's name.
	          personNames.add(sPersonName);
	          nPersons = personNumber;
	          LOGGER.info("Got new person " + sPersonName + " -> nPersons = " + nPersons + " [" + personNames.size() + "]");
	      //  }

	        // Keep the data
	        personNumTruthMat.put(
	                0, // i
	                iFace, // j
	                personNumber); // v

	        // load the face image
	        faceImgArr[iFace] = cvLoadImage(
	                imgFilename, // filename
	                CV_LOAD_IMAGE_GRAYSCALE); // isColor

	        if (faceImgArr[iFace] == null) {
	          throw new RuntimeException("Can't load image from " + imgFilename);
	        }
	      }

	     

	    } catch (Exception ex) {
	      throw new RuntimeException(ex);
	    }

	    LOGGER.info("Data loaded from '" + directoryname + "': (" + nFaces + " images of " + nPersons + " people).");
	    final StringBuilder stringBuilder = new StringBuilder();
	    stringBuilder.append("People: ");
	    if (nPersons > 0) {
	      stringBuilder.append("<").append(personNames.get(0)).append(">");
	    }
	    for (i = 1; i < nPersons && i < personNames.size(); i++) {
	      stringBuilder.append(", <").append(personNames.get(i)).append(">");
	    }
	    LOGGER.info(stringBuilder.toString());
	       
	  System.out.println(personNames);

	    return faceImgArr;
	  }

	  


	  /** Does the Principal Component Analysis, finding the average image and the eigenfaces that represent any image in the given dataset. */
	   public static IplImage[] doPCA(int nTrainFaces, IplImage[] trainingFaceImgArr) {
	    int i;
	    IplImage[] eigenVectArr;
	    CvTermCriteria calcLimit;
	    CvSize faceImgSize = new CvSize();
	    int nEigens = 0;
	    // set the number of eigenvalues to use
	    nEigens = nTrainFaces-1;

	    LOGGER.info("allocating images for principal component analysis, using " + nEigens + (nEigens == 1 ? " eigenvalue" : " eigenvalues"));

	    // allocate the eigenvector images
	    faceImgSize.width(trainingFaceImgArr[0].width());
	    faceImgSize.height(trainingFaceImgArr[0].height());
	    eigenVectArr = new IplImage[nEigens];
	    for (i = 0; i < nEigens; i++) {
	      eigenVectArr[i] = cvCreateImage(
	              faceImgSize, // size
	              IPL_DEPTH_32F, // depth
	              1); // channels
	    }

	    // allocate the eigenvalue array
	    eigenValMat = cvCreateMat(
	            1, // rows
	            nEigens, // cols
	            CV_32FC1); // type, 32-bit float, 1 channel

	    // allocate the averaged image
	    pAvgTrainImg = cvCreateImage(
	            faceImgSize, // size
	            IPL_DEPTH_32F, // depth
	            1); // channels

	    // set the PCA termination criterion
	    calcLimit = cvTermCriteria(
	            CV_TERMCRIT_ITER, // type
	            nEigens, // max_iter
	            1); // epsilon

	    LOGGER.info("computing average image, eigenvalues and eigenvectors");
	    // compute average image, eigenvalues, and eigenvectors
	    cvCalcEigenObjects(
	            nTrainFaces, // nObjects
	            new PointerPointer(trainingFaceImgArr), // input
	            new PointerPointer(eigenVectArr), // output
	            CV_EIGOBJ_NO_CALLBACK, // ioFlags
	            0, // ioBufSize
	            null, // userData
	            calcLimit,
	            pAvgTrainImg, // avg
	            eigenValMat.data_fl()); // eigVals

	    LOGGER.info("normalizing the eigenvectors");
	    cvNormalize(
	            eigenValMat, // src (CvArr)
	            eigenValMat, // dst (CvArr)
	            1, // a
	            0, // b
	            CV_L1, // norm_type
	            null); // mask
	    
	    return eigenVectArr;
	  }
	   
	   
		  
		  /**
		  * List all the files under a directory
		  * @param directoryName to be listed
		  */
		public static List<String> listFiles(String directoryName) {
			File directory = new File(directoryName);
			List<String> fileNames = new ArrayList<String>();
			// get all the files from a directory
			File[] fList = directory.listFiles();
			for (File file : fList) {
				if (file.isFile()) {
					fileNames.add(file.getName());

				}
			}
			
			return fileNames;
		}
	   

	 
}
