package com.att.facerecognition.exceptions;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class FacedetectionException extends WebApplicationException {
	private String message = null;

	public FacedetectionException() {
		super();
	}

	public FacedetectionException(String message) {
		super(Response.status(Response.Status.BAD_REQUEST)
	             .entity(message).type(MediaType.TEXT_PLAIN).build());
		this.message = message;
	}

	public FacedetectionException(Throwable cause) {
		super(cause);
	}

	
	@Override
	public String toString() {
		return message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
