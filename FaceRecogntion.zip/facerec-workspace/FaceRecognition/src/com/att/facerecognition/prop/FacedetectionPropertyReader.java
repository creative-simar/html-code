package com.att.facerecognition.prop;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.att.facerecognition.exceptions.PropertyFileException;

public class FacedetectionPropertyReader {

	private InputStream input = null;
	private Properties prop = null;

	public FacedetectionPropertyReader(String sFileName)
			throws PropertyFileException, IOException {
		input = new FileInputStream(sFileName);
		prop = new Properties();
		prop.load(input);
	}

	public String readProperty(String sTag) throws PropertyFileException {
		return prop.getProperty(sTag);
	}

}
