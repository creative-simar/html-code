package com.att.facelearning.core;

import static com.googlecode.javacv.cpp.opencv_highgui.CV_LOAD_IMAGE_GRAYSCALE;
import static com.googlecode.javacv.cpp.opencv_highgui.cvLoadImage;
import static com.googlecode.javacv.cpp.opencv_legacy.cvEigenDecomposite;

import java.io.IOException;
import java.util.logging.Logger;

import com.att.facedb.utility.FacerecogntionUtiltiy;
import com.att.facedetection.core.Facedetection;
import com.att.facelearning.db.FaceDBLoading;
import com.att.facerecognition.exceptions.FacedetectionException;
import com.att.facerecognize.main.FaceRecognitionMain;
import com.googlecode.javacpp.FloatPointer;
import com.googlecode.javacpp.PointerPointer;
import com.googlecode.javacv.cpp.opencv_core.CvMat;
import com.googlecode.javacv.cpp.opencv_core.IplImage;

public class FaceRecognizer {

	/** the logger */
	private static final Logger LOGGER = Logger
			.getLogger(FaceRecognitionMain.class.getName());

	/**
	 * Recognizes the face in each of the test images given, and compares the
	 * results with the truth.
	 * 
	 * @param szFileTest
	 *            the index file of test images
	 * @throws IOException
	 * @throws FacedetectionException
	 */
	public static String recognizeFace(String imageFileToRecognize,
			String facedbDirectory, String cascadeAlgorithmXMLPath,
			String destinationDirectoryName) throws IOException,
			FacedetectionException {
		LOGGER.info("===========================================");
		LOGGER.info("recognizing faces indexed from " + imageFileToRecognize);
		int i = 0;
		int nTestFaces = 0; // the number of test images
		CvMat trainPersonNumMat; // the person numbers during training

		float confidence = 0.0f;
		IplImage[] eigenVectArr;
		IplImage pAvgTrainImg;
		int nEigens;
		int nTrainFaces;
		CvMat projectedTrainFaceMat;
		IplImage faceToBeRecognize;

		imageFileToRecognize = Facedetection.detectFaces(imageFileToRecognize,
				cascadeAlgorithmXMLPath, destinationDirectoryName);
		// load the saved training data
		trainPersonNumMat = FaceDBLoading.loadTrainingData(facedbDirectory);
		if (trainPersonNumMat == null) {
			throw new FacedetectionException(
					"Error in loading Face data from - " + facedbDirectory);
		}
		nEigens = FaceDBLoading.getnEigens();
		nTrainFaces = FaceDBLoading.getnTrainFaces();
		eigenVectArr = FaceDBLoading.getEigenVectArr();
		pAvgTrainImg = FaceDBLoading.getpAvgTrainImg();
		projectedTrainFaceMat = FaceDBLoading.getProjectedTrainFaceMat();

		faceToBeRecognize = cvLoadImage(imageFileToRecognize, // filename
				CV_LOAD_IMAGE_GRAYSCALE); // isColor

		// project the test images onto the PCA subspace
		float[] projectedTestFace = new float[nEigens];
		int iNearest;
		int nearest;
		// project the test image onto the PCA subspace
	
		cvEigenDecomposite(faceToBeRecognize, // obj
				nEigens, // nEigObjs
				new PointerPointer(eigenVectArr), // eigInput (Pointer)
				0, // ioFlags
				null, // userData
				pAvgTrainImg, // avg
				projectedTestFace); // coeffs

		final FloatPointer pConfidence = new FloatPointer(confidence);
		iNearest = NearestMatch.findNearestNeighbor(projectedTestFace,
				new FloatPointer(pConfidence), projectedTrainFaceMat, nEigens,
				nTrainFaces);
		confidence = pConfidence.get();
		// truth = personNumTruthMat.data_i().get(i);
		
		
		if(Float.compare(confidence, -2.5f) < 0)
		{
			LOGGER.info("The data is not found in training images.");
		 	nearest = -1;
		 	throw new FacedetectionException("The data is not found in training images.");
		 }
		 else
		 {
			 nearest = trainPersonNumMat.data_i().get(iNearest);

			 LOGGER.info("The Best match is :" + nearest);
		 }

		return FacerecogntionUtiltiy.getNamefromFile(nearest, facedbDirectory);
	}

}
