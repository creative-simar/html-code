package com.att.facedb.utility;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.opencv.core.Rect;

public class FacerecogntionUtiltiy {
	
    
  static public String getNamefromFile(int nearest,String facedbDirectory) throws IOException {	
	  
	  BufferedReader br = new BufferedReader(new FileReader(facedbDirectory + "\\PersonNames.txt"));
	  List<String> personName = new ArrayList<String>();
	  String line;
	  while ( (line = br.readLine()) != null) {	  
		  personName.addAll(Arrays.asList(line.split(",")));		 
	  }
	  br.close();	  
	  line = "";
	  line = personName.get(nearest);
	  line = line.substring(0, line.length()-4);
	  line = line.replace("[", "");
	  line = line.replace("]", "");
	  return line; 
	  
}
  
  

	public static int getMaxValueIndex(Rect[] array){  
	      int maxValue = array[0].height;  
	      for(int i=1;i < array.length;i++){  
	      if(array[i].height > maxValue){  
	    	  maxValue = i;  
	         }  
	     }  
	             return maxValue;  
	}  


}
