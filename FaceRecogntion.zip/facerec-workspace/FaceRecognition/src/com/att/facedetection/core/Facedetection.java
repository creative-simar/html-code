package com.att.facedetection.core;

import java.io.File;
import java.util.logging.Logger;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;

import com.att.facedb.utility.FacerecogntionUtiltiy;
import com.att.facerecognition.exceptions.FacedetectionException;
import com.att.facerecognize.main.FaceRecognitionMain;

public class Facedetection {

	private final static Logger LOGGER = Logger
			.getLogger(FaceRecognitionMain.class.getName());

	public static String detectFaces(String imageFileToRecognize,
			 String cascadeAlgorithmXMLPath, String destinationDirectoryName)
			 throws FacedetectionException {
		Mat image = null;
		Mat grey_image = null;
		MatOfRect faceDetections = null;
		Rect[] rect = null;
		Mat cropImageRegion = null;
		String filename = "";
		int index = 0;
		
		LOGGER.info("Starting face detection.");
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		LOGGER.info("Open CV library loaded sucessfully.");
		
		CascadeClassifier faceDetector = new CascadeClassifier();
		if(!faceDetector.load(cascadeAlgorithmXMLPath)) throw new FacedetectionException("Error in loading cascade algorithm XML :" + cascadeAlgorithmXMLPath);
		
		File path = new File(imageFileToRecognize);
		if(!path.isFile()) throw new FacedetectionException("Invalid path for Image file to recongize is specfied.");
		
		//destinationDirectoryName = path.getParent();
		
		//File [] files = path.listFiles();
	   // for (int i = 0; i < files.length; i++){
	    //    if (files[i].isFile()){ 
	        	image = null;faceDetections = null;rect=null;cropImageRegion = null;
	        	image = Highgui.imread(path.getAbsolutePath());
	        	faceDetections = new MatOfRect();
	        	grey_image = new Mat();
	        	Imgproc.cvtColor(image, grey_image, Imgproc.COLOR_BGRA2GRAY);
	            Imgproc.equalizeHist(grey_image, grey_image);
	        	LOGGER.info("\nRunning FaceDetector");
	        	
	        	faceDetector.detectMultiScale(image, faceDetections);
	    		LOGGER.info(String.format("Detected %s faces",
	    				faceDetections.toArray().length));
	    		rect = faceDetections.toArray();		
	    		// As we are considering only 1 face which is at index 0
	    		if(rect.length==0) 
	    			throw new FacedetectionException("Error in detecting face from the Image. Please try again later.");
	    		if(rect.length>1)
	    		{
	    			index = FacerecogntionUtiltiy.getMaxValueIndex(rect);
	    		}	    		
	    		cropImageRegion = new Mat(image, new Rect(rect[index].x, rect[index].y,
	    				rect[index].width, rect[index].height));
	    		
	    		filename = destinationDirectoryName + File.separator + path.getName();
	    		//path.delete();
	    		Mat resizeimage = new Mat();
	    		Size sz = new Size(100,100);
	    		Imgproc.resize( cropImageRegion, resizeimage, sz );
	    		
	    		LOGGER.info(String.format("Writing %s", filename));
	    		Highgui.imwrite(filename, resizeimage);

	    		return filename;
	  //      }
	  //  }
		
	    
		
	}
	
	

	
}
