function capture(video, canvas, image, snapshotButton) {
	var ctx = canvas.getContext('2d');
	var localMediaStream = null;
	snapshotButton.disabled = false;

	window.URL = window.URL || window.webkitURL;
	navigator.getUserMedia = navigator.getUserMedia
			|| navigator.webkitGetUserMedia || navigator.mozGetUserMedia
			|| navigator.msGetUserMedia;

	var constraints = {
		video : true
	};

	var successCallback = function(mediaStream) {
		video.src = (window.URL && window.URL.createObjectURL(mediaStream))
				|| mediaStream;
		video.addEventListener("loadedmetadata", function(e) {
			video.style.display = "block";
			localMediaStream = mediaStream;
			snapshotButton.onclick = function(event) {
				takePhoto();
			};
		});
	};

	var errorCallback = function() {
		console.log("failure to get media");
	};

	var takePhoto = function() {
		ctx.drawImage(video, 0, 0, 900, 500);
		canvas.style.display = "none";
		storeImage();
		stop(video);
	};

	var storeImage = function() {
		var imgFileName;
		xmlhttp.open("POST",
				"http://localhost:8080/facerecogntion/rest/file/upload", true);
		var dataURL = canvas.toDataURL('image/webp;charset=utf-8', 1.0);
		xmlhttp.setRequestHeader("Content-type", "image/webp");
		xmlhttp.setRequestHeader("Content-length", dataURL.length);
		xmlhttp.setRequestHeader("Connection", "close");

		if(get_cookie('username')=='')
			imgFileName ="recognize";
		else
			imgFileName = get_cookie('username');
		
		var jsonData = {
			imageData : [ dataURL ],
			imageFileName : [ imgFileName ]
		};		
		xmlhttp.send(JSON.stringify(jsonData));
		delete_cookie('username');
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4) {
				if (xmlhttp.status == 200) {
					if (document.querySelector('#snapshotButton').innerHTML=="Register")
					{
						alert("Image Registered Sucessfully.");
						window.location.href = "/facerecogntion/index.html";						
					}
					else
					{
						//alert(xmlhttp.response);
						var json = JSON.parse(xmlhttp.response);											 
						set_cookie('username',json.username,5);
						set_cookie('session_id',json.session_id,5);
						window.location.href = "dashboard.html";	
					}
				}
				else
				{
					if (document.querySelector('#snapshotButton').innerHTML=="Register")
					{
						alert("Error in Face Resgistration: " + xmlhttp.responseText);	
						window.location.href = "/facerecogntion/index.html";
					}
					else
					{
						alert("Authentication Error: " + xmlhttp.responseText);
						window.location.href = "/facerecogntion/index.html";
					}
					 
				}
				
			}
		};

	};

	var stop = function() {
		if (localMediaStream) {
			localMediaStream.stop(); /*
										 * TODO: it doesn't work in Opera Mobile
										 * 12
										 */
		}
		snapshotButton.disabled = true;
	};

	if (navigator.getUserMedia) {
		navigator.getUserMedia(constraints, successCallback, errorCallback);
	} else {
		console.log("getUserMedia not supported");
	}
}

function dataURItoBlob(dataURI) {
	var byteString, mimestring;

	if (dataURI.split(',')[0].indexOf('base64') !== -1) {
		byteString = atob(dataURI.split(',')[1]);
	} else {
		byteString = decodeURI(dataURI.split(',')[1]);
	}

	mimestring = "image/jpeg";

	var content = new Array();
	for ( var i = 0; i < byteString.length; i++) {
		content[i] = byteString.charCodeAt(i);
	}

	return new Blob([ new Uint8Array(content) ], {
		type : mimestring
	});
}

function get_cookie(cookie_name) {
	/*var cookie_string = document.cookie;
	if (cookie_string.length > 0) {
		var cookie_value = cookie_string.match('(^|;)[\s]*' + cookie_name
				+ '=([^;]*)');
		return decodeURIComponent(cookie_value[2]);
	}
	return '';*/

		var theCookie=" "+document.cookie;
 var ind=theCookie.indexOf(" "+cookie_name+"=");
 if (ind==-1) ind=theCookie.indexOf(";"+cookie_name+"=");
 if (ind==-1 || cookie_name=="") return "";
 var ind1=theCookie.indexOf(";",ind+1);
 if (ind1==-1) ind1=theCookie.length; 
 return unescape(theCookie.substring(ind+cookie_name.length+2,ind1));
}

function delete_cookie(cookie_name) {
	document.cookie = cookie_name + "=; max-age=0;";
}

function init() {
	
	var video = document.querySelector('video#getUserMedia');
	var canvas = document.querySelector('#canvas');
	var snapshot = document.querySelector('#snapshot');
	var snapshotButton = document.querySelector('#snapshotButton');
	if(get_cookie('username')=='')
		snapshotButton.innerHTML="Login";
	else
		snapshotButton.innerHTML="Register";
	
	capture(video, canvas, snapshot, snapshotButton);
	xmlhttp = new XMLHttpRequest();
}

function set_cookie ( cookie_name, cookie_value, lifespan_in_days)
{
     document.cookie = cookie_name + "=" + encodeURIComponent( cookie_value ) +
      "; max-age=" + 60 * 60 * lifespan_in_days + "; path=/facerecogntion/html"  ;
} 