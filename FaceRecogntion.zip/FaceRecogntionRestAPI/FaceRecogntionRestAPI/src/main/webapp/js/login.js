 var xmlhttp;
   
 function init() {
       // put more code here in case you are concerned about browsers that do not provide XMLHttpRequest object directly
       xmlhttp = new XMLHttpRequest();
	   delete_cookie('username');
 }
  
function fnlogin(urlPath)
{
		var username = document.getElementById("username").value;
		var password = document.getElementById("password").value;
		if(username=="")
			{
				alert("Please enter username"); return;
			}
		if(password=="")
			{
				alert("Please enter password"); return;
			}		
        var url = "http://localhost:8080/facerecogntion/rest/login/loginapi?username=" + username + "&password=" + password;
        xmlhttp.open('GET',url,true);
        xmlhttp.send(null);
        xmlhttp.onreadystatechange = function() {
               if (xmlhttp.readyState == 4) {
                  if (xmlhttp.status == 200) {
                 		if(xmlhttp.responseText!="")
						{
							//if(urlPath=="capture.html")
								set_cookie('username',username,2);
								set_cookie('session_id',xmlhttp.responseText,2);
							window.location.href=urlPath;
						}
						else
							alert("Not Authorised User");
                 }
                 else
                       alert("Authentication Error: " + xmlhttp.responseText);
              }
        };
}

function facelogin()
{
	window.location.href = "html/capture.html";
}


function delete_cookie(cookie_name) {
	document.cookie = cookie_name + "=''; max-age=0; path=/facerecogntion/html";
	document.cookie = cookie_name + "=''; max-age=0; path=/facerecogntion";
}

function set_cookie ( cookie_name, cookie_value, lifespan_in_days)
{
     document.cookie = cookie_name + "=" + encodeURIComponent( cookie_value ) +
      "; max-age=" + 60 * 60 * lifespan_in_days + ";path=/facerecogntion/html";
}