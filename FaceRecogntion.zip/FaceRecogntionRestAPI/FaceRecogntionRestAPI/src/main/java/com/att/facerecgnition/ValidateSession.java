package com.att.facerecgnition;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.att.facerecognition.exceptions.PropertyFileException;
import com.att.facerecognition.prop.FacerecdbPropertyReader;

public class ValidateSession {
	
	
	public boolean sessionValidator(String username, String sessionId,FacerecdbPropertyReader fdProperties)
			throws PropertyFileException {

		String dbUrl = fdProperties.readProperty("dbURL");
		String dbClass = fdProperties.readProperty("dbClass");
		String query = "Select salt from users where username=";
		String dbusername = fdProperties.readProperty("dbUsername");
		String dbpassword = fdProperties.readProperty("dbPassword");
		String tempString = "";
		boolean returntype = false;
		try {
			Class.forName(dbClass);
			Connection connection = DriverManager.getConnection(dbUrl,
					dbusername, dbpassword);
			query += "'" + username + "'";
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(query);
			if(resultSet.next()) tempString = resultSet.getString(1);
			else tempString = "";
			statement.close();
			resultSet.close();
			if(null==tempString)
			{
				returntype = false;
			}
			else if (tempString.equalsIgnoreCase(sessionId)) 
			{
				returntype = true;
			}			
			connection.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return returntype;
	}
	

}
