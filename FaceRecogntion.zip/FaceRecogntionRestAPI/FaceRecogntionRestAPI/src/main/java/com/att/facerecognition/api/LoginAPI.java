package com.att.facerecognition.api;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import com.att.facerecgnition.ValidateSession;
import com.att.facerecgnition.rs.LoginAuthentication;
import com.att.facerecognition.exceptions.PropertyFileException;
import com.att.facerecognition.prop.FacerecdbPropertyReader;
import com.att.facerecogntion.facedetection.FaceDetection;

@Path("login")
public class LoginAPI {
	
	/** the logger */
	private static final Logger LOGGER = Logger
			.getLogger(LoginAPI.class.getName());
	
	@GET
    @Path("loginapi")
    public String simpleloginAPI(@QueryParam("username") String username,@QueryParam("password") String password){
       LoginAuthentication la;
       String returnValue = "";
       try
       {
    	
        la= new LoginAuthentication();
        returnValue =  String.valueOf(la.login(username, password));
       }
       catch(IOException ioe)
       {
    	   LOGGER.log(Level.ALL,
					"Exception in property file module : " + ioe.getStackTrace());
			ioe.printStackTrace();
       }
       catch(PropertyFileException pfe)
       {
    	   LOGGER.log(Level.ALL,
					"Exception in property file module : " + pfe.getStackTrace());
			pfe.printStackTrace();
       }
       return returnValue;
    }
	
	
	@GET
    @Path("logoutapi")
    public String logoutAPI(@QueryParam("username") String username) throws PropertyFileException, IOException, ClassNotFoundException, SQLException{
				FacerecdbPropertyReader	fRecProperties = new FacerecdbPropertyReader(
								"facerecoconfig.properties");
				String dbUrl = fRecProperties.readProperty("dbURL");
				String dbClass = fRecProperties.readProperty("dbClass");
				String dbusername = fRecProperties.readProperty("dbUsername");
				String dbpassword = fRecProperties.readProperty("dbPassword");		
				String returntype = "false";
				String sQuery =  "Update users set salt=NULL " + " where username='" + username+"'";
						
				Class.forName(dbClass);
				Connection connection = DriverManager.getConnection(dbUrl,
						dbusername, dbpassword);				
				PreparedStatement ps = connection.prepareStatement(sQuery);				
				ps.executeUpdate();				
				ps.close();
				connection.close();
				returntype="true";
				return returntype;
	}
	
	@GET
    @Path("validate")
    public String validateSession(@QueryParam("username") String username,@QueryParam("session_id") String sessionId) throws PropertyFileException, IOException, ClassNotFoundException, SQLException{
				FacerecdbPropertyReader	fRecProperties = new FacerecdbPropertyReader(
								"facerecoconfig.properties");
				 ValidateSession session;
			     session= new ValidateSession();
			     LOGGER.log(Level.ALL,
							"Validate Session - username" + username);
			     LOGGER.log(Level.ALL,
							"Validate Session - session_id" + sessionId);
			    
			    String returnValue =  String.valueOf(session.sessionValidator(username, sessionId,fRecProperties));
			     
			    LOGGER.log(Level.ALL,
						"Validate Session - username" + username);
			    LOGGER.log(Level.ALL,
						"Validate Session - session_id" + sessionId);
		     
			    return returnValue;
			    
			     
	}
	
}
