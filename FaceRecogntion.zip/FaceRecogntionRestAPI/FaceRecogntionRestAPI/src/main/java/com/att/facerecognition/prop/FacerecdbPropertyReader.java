package com.att.facerecognition.prop;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.att.facerecognition.exceptions.PropertyFileException;

public class FacerecdbPropertyReader {
	private Properties prop = null;

	public FacerecdbPropertyReader(String sFileName)
			throws PropertyFileException, IOException {
		prop = new Properties();
		prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(sFileName));
	}

	public String readProperty(String sTag) throws PropertyFileException {
		return prop.getProperty(sTag);
	}

}
