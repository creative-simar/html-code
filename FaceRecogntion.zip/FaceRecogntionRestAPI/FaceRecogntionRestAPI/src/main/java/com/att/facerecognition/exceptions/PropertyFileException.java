package com.att.facerecognition.exceptions;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
public class PropertyFileException extends WebApplicationException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	private String message = null;

	public PropertyFileException() {
		super();
	}

	public PropertyFileException(String message) {
		super(Response.status(Response.Status.BAD_REQUEST)
	             .entity(message).type(MediaType.TEXT_PLAIN).build());
		this.message = message;
	}

	public PropertyFileException(Throwable cause) {
		super(cause);
	}

	
	@Override
	public String toString() {
		return message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
