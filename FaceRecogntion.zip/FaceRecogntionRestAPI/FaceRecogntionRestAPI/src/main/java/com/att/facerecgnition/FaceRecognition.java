package com.att.facerecgnition;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.simple.JSONObject;

import com.att.facedetection.core.FacedetectionUtility;
import com.att.facelearning.core.FaceRecognizer;
import com.att.facerecognition.exceptions.FacedetectionException;
import com.att.facerecognition.exceptions.PropertyFileException;
import com.att.facerecognition.prop.FacerecdbPropertyReader;
import com.att.facerecogntion.facedetection.FaceDetection;

public class FaceRecognition {

	public static String detectandRecognizeFace(String uploadedFileLocation,
			FacerecdbPropertyReader fRecProperties)
			throws PropertyFileException,
			FacedetectionException, IOException {

		
		FacedetectionUtility.checkDirectoryandCreate(fRecProperties
				.readProperty("faceRecogntionDir"));
		
		return FaceRecognizer.recognizeFace(uploadedFileLocation,
				fRecProperties.readProperty("uploadFaceRecData"),
				fRecProperties.readProperty("cascadeAlgorithmXMLPath"),
				fRecProperties.readProperty("faceRecogntionDir"));
		
	}
	
	public static String generateJson(String output, FacerecdbPropertyReader fRecProperties) {
		String outString="";		
		JSONObject obj=new JSONObject();
		obj.put("username",output);		
		obj.put("session_id",FaceRecognition.faceLogin(output, fRecProperties));					
		return obj.toJSONString();		
	}
	
	public static String faceLogin (String username,FacerecdbPropertyReader fRecProperties)
			throws PropertyFileException {

		String dbUrl = fRecProperties.readProperty("dbURL");
		String dbClass = fRecProperties.readProperty("dbClass");
		String dbusername = fRecProperties.readProperty("dbUsername");
		String dbpassword = fRecProperties.readProperty("dbPassword");		
		String returntype = "";
		try {
				username = username.replace(".", "");
				username= username.trim();
				Class.forName(dbClass);
				Connection connection = DriverManager.getConnection(dbUrl,
						dbusername, dbpassword);
				returntype = String.valueOf(FaceDetection.randInt(0, 999999999));
				PreparedStatement ps = connection.prepareStatement("Update users set salt='"+ returntype +"' where username='" + username+"'");
				ps.execute();				
				ps.close();
				connection.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return returntype;
	}

}
