package com.att.facerecgnition.rs;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.DatatypeConverter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.att.facedetection.core.FacedetectionUtility;
import com.att.facerecgnition.FaceRecognition;
import com.att.facerecognition.exceptions.FacedetectionException;
import com.att.facerecognition.exceptions.PropertyFileException;
import com.att.facerecognition.prop.FacerecdbPropertyReader;
import com.att.facerecogntion.facedetection.FaceDetection;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

@Path("/file")
public class FaceAuthentication {

	private FacerecdbPropertyReader fRecProperties = null;

	public FaceAuthentication() {
		try {
			fRecProperties = new FacerecdbPropertyReader(
					"facerecoconfig.properties");
		} catch (PropertyFileException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@POST
	@Path("/upload")
	@Consumes(MediaType.WILDCARD)
	public Response uploadFile(String image) throws IOException,
			ParseException, FacedetectionException, PropertyFileException,
			com.att.facedetection.exception.FacedetectionException {

		String uploadedFileLocation = "";
		String output = "";
		JSONObject jsonobj;
		JSONArray imageData;
		String sImageData;
		JSONArray imageFileName;
		String sImageFileName;
		BufferedImage imageRGB = null;
		String propertyToRead = "";
		// System.out.println("123");
		jsonobj = (JSONObject) new JSONParser().parse(image);// JSONArray(image);
		imageData = (JSONArray) jsonobj.get("imageData");
		imageFileName = (JSONArray) jsonobj.get("imageFileName");

		sImageData = imageData.toString().replace("[\"", "");
		sImageData = sImageData.replace("\"]", "");
		sImageData = sImageData.replace("data:image\\/png;base64,", ""); // data:image\/png;base64,
		// System.out.println(sImageData);

		byte[] decodedBytes = DatatypeConverter.parseBase64Binary(sImageData);
		BufferedImage bfi = ImageIO
				.read(new ByteArrayInputStream(decodedBytes));

		sImageFileName = imageFileName.toString().replace("[\"", "");
		sImageFileName = sImageFileName.replace("\"]", "");
		// System.out.println(sImageFileName);

		imageRGB = new BufferedImage(bfi.getWidth(), bfi.getHeight(),
				BufferedImage.TYPE_INT_RGB);

		imageRGB.createGraphics().drawImage(bfi, 0, 0, Color.WHITE, null);

		// imageRGB.setData(bfi.getData());

		if (sImageFileName.equalsIgnoreCase("recognize")) {
			propertyToRead = "processFaceRecDir";
		} else {

			propertyToRead = "uploadRawFileLocation";
		}

		FacedetectionUtility.checkDirectoryandCreate(fRecProperties
				.readProperty(propertyToRead));

		uploadedFileLocation = fRecProperties.readProperty(propertyToRead)
				+ sImageFileName + ".jpg";

		File outputfile = new File(uploadedFileLocation);
		ImageIO.write(imageRGB, "JPEG", outputfile);
		imageRGB.flush();

		if (propertyToRead.equalsIgnoreCase("uploadRawFileLocation")) {
			output = FaceDetection.detectandLoadFaces(uploadedFileLocation,
					fRecProperties);
		} else {
			output = FaceRecognition.detectandRecognizeFace(
					uploadedFileLocation, fRecProperties);
		}

		return Response.status(200)
				.entity(FaceRecognition.generateJson(output, fRecProperties))
				.build();

	}

	@POST
	@Path("/uploadmobile")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadfileleonMobile(
			@FormDataParam("file") InputStream uploadedInputStream,
			@FormDataParam("file") FormDataContentDisposition fileDetail,
			@FormDataParam("imageFileName") String sImageFileName)
			throws IOException, ParseException, FacedetectionException,
			PropertyFileException,
			com.att.facedetection.exception.FacedetectionException {

		String uploadedFileLocation = "";
		String output = "";
		String propertyToRead = "";
		// System.out.println("123");

		if (sImageFileName.equalsIgnoreCase("recognize")) {
			propertyToRead = "processFaceRecDir";
		} else {

			propertyToRead = "uploadRawFileLocation";
		}

		FacedetectionUtility.checkDirectoryandCreate(fRecProperties
				.readProperty(propertyToRead));

		uploadedFileLocation = fRecProperties.readProperty(propertyToRead)
				+ sImageFileName;
		// save it
		writeToFile(uploadedInputStream, uploadedFileLocation);

		if (propertyToRead.equalsIgnoreCase("uploadRawFileLocation")) {
			output = FaceDetection.detectandLoadFaces(uploadedFileLocation,
					fRecProperties);
		} else {
			output = FaceRecognition.detectandRecognizeFace(
					uploadedFileLocation, fRecProperties);
		}

		return Response.status(200)
				.entity(FaceRecognition.generateJson(output, fRecProperties))
				.build();

	}

	// save uploaded file to new location
	private void writeToFile(InputStream uploadedInputStream,
			String uploadedFileLocation) {

		try {
			OutputStream out = new FileOutputStream(new File(
					uploadedFileLocation));
			int read = 0;
			byte[] bytes = new byte[1024];
			out = new FileOutputStream(new File(uploadedFileLocation));
			while ((read = uploadedInputStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			out.flush();
			out.close();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public FaceAuthentication(FacerecdbPropertyReader fdProperties) {
		super();
		this.fRecProperties = fdProperties;
	}

}
