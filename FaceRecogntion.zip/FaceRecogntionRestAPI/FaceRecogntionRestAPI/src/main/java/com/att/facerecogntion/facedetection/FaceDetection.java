package com.att.facerecogntion.facedetection;

import java.io.IOException;
import java.util.Random;

import com.att.facedetection.core.FacedetectionUtility;
import com.att.facedetection.exception.FacedetectionException;
import com.att.facelearning.core.FaceLearning;
import com.att.facerecognition.exceptions.PropertyFileException;
import com.att.facerecognition.prop.FacerecdbPropertyReader;
import com.att.facedetection.core.Facedetection;

public class FaceDetection {

	public static String detectandLoadFaces(String uploadedFileLocation, FacerecdbPropertyReader fRecProperties) throws FacedetectionException, PropertyFileException, IOException, com.att.facerecognition.exceptions.FacedetectionException {
		
		String output;
		
		FacedetectionUtility.checkDirectoryandCreate(fRecProperties
				.readProperty("uploadFaceImgLocation"));
		Facedetection.detectFaces(uploadedFileLocation,
				fRecProperties.readProperty("cascadeAlgorithmXMLPath"),
				fRecProperties.readProperty("uploadFaceImgLocation"));
		output = "File uploaded to : " + uploadedFileLocation;
		FacedetectionUtility.checkDirectoryandCreate(fRecProperties
				.readProperty("uploadFaceRecData"));
		FaceLearning.learn(
				fRecProperties.readProperty("uploadFaceImgLocation"),
				fRecProperties.readProperty("uploadFaceRecData"));

		return output;
	}
	
	
	
	public static int randInt(int min, int max) {

	    // NOTE: Usually this should be a field rather than a method
	    // variable so that it is not re-seeded every call.
	    Random rand = new Random();

	    // nextInt is normally exclusive of the top value,
	    // so add 1 to make it inclusive
	    int randomNum = rand.nextInt((max - min) + 1) + min;

	    return randomNum;
	}

}
