package com.att.facerecgnition.rs;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.att.facerecognition.exceptions.PropertyFileException;
import com.att.facerecognition.prop.FacerecdbPropertyReader;
import com.att.facerecogntion.facedetection.FaceDetection;

public class LoginAuthentication {

	private FacerecdbPropertyReader fdProperties = null;

	public LoginAuthentication() throws PropertyFileException, IOException {
		fdProperties = new FacerecdbPropertyReader("facerecoconfig.properties");
	}

	public String login(String username, String password)
			throws PropertyFileException {

		String dbUrl = fdProperties.readProperty("dbURL");
		String dbClass = fdProperties.readProperty("dbClass");
		String query = "Select password from users where username=";
		String dbusername = fdProperties.readProperty("dbUsername");
		String dbpassword = fdProperties.readProperty("dbPassword");
		String tempString = "";
		String returntype = "";
		try {
			Class.forName(dbClass);
			Connection connection = DriverManager.getConnection(dbUrl,
					dbusername, dbpassword);
			query += "'" + username + "'";
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(query);
			if(resultSet.next()) tempString = resultSet.getString(1);
			else tempString = "";
			statement.close();
			resultSet.close();
			if (tempString.equalsIgnoreCase(password)) 
			{
				returntype = String.valueOf(FaceDetection.randInt(0, 999999999));
				PreparedStatement ps = connection.prepareStatement("Update users set salt='"+ returntype +"' where username='" + username+"'");
				ps.execute();				
				ps.close();
			}			
			connection.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return returntype;
	}

}
