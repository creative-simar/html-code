var strUsername;

function init() {
      
	strUsername = get_cookie('username').replace(/\s+/, "");
	strUsername = strUsername.replace('.','');
	if(strUsername!="")
	{
		document.getElementById("userimg").src = "http://localhost:8080/facerec/images/" + strUsername + ".jpg";     
	}
	else
	{
		strUsername = 'User';
		document.getElementById("userimg").src = "../images/user-icon.png"; 
	}
	   
	document.getElementById("user_name").innerHTML = strUsername;
	
	var httpxml = new XMLHttpRequest();
	
	var username = strUsername;
	var session = get_cookie('session_id').replace(/\s+/, "");
	if(username=="true")
		{
			alert("Not valid user");  window.location.href = '/facerecogntion/index.html'; return;
		}
	if(session=="true")
		{
			alert("Not valid session "); window.location.href = '/facerecogntion/index.html'; return;
		}		
	
    var url = "http://localhost:8080/facerecogntion/rest/login/validate/?username=" + username + "&session_id=" + session;
    httpxml.open('GET',url,true);
    httpxml.send(null);
    httpxml.onreadystatechange = function() {
           if (httpxml.readyState == 4) {
              if (httpxml.status == 200) {
            	   //alert(httpxml.responseText);
             		if(httpxml.responseText=="true")
					{             			
						return;
					}
					else
					{
						alert("Session validation failed.");
						window.location.href = '/facerecogntion/index.html';
					}
             }
             else
                   alert("Authentication Error: " + xmlhttp.responseText);
          }
    };
    
	
	

 }


 function get_cookie(cookie_name) {
	/*var cookie_string = document.cookie;
	if (cookie_string.length > 0) {
		var cookie_value = cookie_string.match('(^|;)[\s]*' + cookie_name
				+ '=([^;]*)');
		return decodeURIComponent(cookie_value[2]);
	}
	return '';*/

	var theCookie=" "+document.cookie;
 var ind=theCookie.indexOf(" "+cookie_name+"=");
 if (ind==-1) ind=theCookie.indexOf(";"+cookie_name+"=");
 if (ind==-1 || cookie_name=="") return "";
 var ind1=theCookie.indexOf(";",ind+1);
 if (ind1==-1) ind1=theCookie.length; 
 return unescape(theCookie.substring(ind+cookie_name.length+2,ind1));
}
 
 
 
function logOut()
{
	
	var xmlhttp = new XMLHttpRequest();
	var url = "http://localhost:8080/facerecogntion/rest/login/logoutapi?username=" + strUsername ;
    xmlhttp.open('GET',url,true);
    xmlhttp.send(null);
    xmlhttp.onreadystatechange = function() {
           if (xmlhttp.readyState == 4) {
              if (xmlhttp.status == 200) {
             		alert("User logged out.");
					
             }
             else
                   alert("Error in Logout: " + xmlhttp.responseText);
          }
    };
    delete_cookie('username');
    delete_cookie('session_id');
	window.location.href = '/facerecogntion/index.html';
	
}


function delete_cookie(cookie_name) {
	document.cookie = cookie_name + "=''; max-age=0; path=/facerecogntion/html";
	document.cookie = cookie_name + "=''; max-age=0; path=/facerecogntion";
}
