function configure() {
	
}

configure.prototype.serverName = "INCDSZPC01403";
configure.prototype.portNumber = "9004";
// for search engine
configure.prototype.searchServer = "INCDSZPC01309";
configure.prototype.searchPort = "8090";

//for text to speech call
configure.prototype.ttsCall = function(inputVal) {
	AttApiClient.Speech.textToSpeech({
		text: inputVal
	},
	function (blob) {
        console.log(blob);
        var url = URL.createObjectURL(blob);
        var au = document.createElement('audio');
        au.controls = true;
        au.src = url;
        au.play();
	});
}
